package com.sureshit.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table 
public class StockPriceDao {
	
 
@Id
@GeneratedValue
private int id;
private String company;
private Float price;
 
 
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCompany() {
	return company;
}
public void setCompany(String company) {
	this.company = company;
}
public Float getPrice() {
	return price;
}
public void setPrice(Float price) {
	this.price = price;
}
@Override
public String toString() {
	return "StockPriceDao [id=" + id + ", company=" + company + ", price=" + price + "]";
}
public StockPriceDao(String company, Float price) {
	super();
	this.company = company;
	this.price = price;
}
public StockPriceDao() {
	super();
}




}
