package com.sureshit.rest;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sureshit.dao.StockPriceDao;
import com.sureshit.dto.StockPriceDto;
import com.sureshit.repo.StockPriceRepository;

@RestController
public class StockPriceRestController {

	@Autowired
	private StockPriceRepository stockPriceRepository;
	ModelMapper modelMapper = new ModelMapper();

	@PostMapping("/postingprice")
	public String postStockPrice(@RequestBody StockPriceDto stockPriceDto) {

		StockPriceDao stockPriceDao = new StockPriceDao();
		modelMapper.map(stockPriceDto, stockPriceDao);
		StockPriceDao result = stockPriceRepository.save(stockPriceDao);

		return "Data inserted successfully with ID : " + result.getId();
	}

	@GetMapping("price/{cname}")
	public Float getStockPrice(@PathVariable String cname) {

		StockPriceDao stockPriceDao = stockPriceRepository.findByCompany(cname);
		return stockPriceDao.getPrice();
	}

}
