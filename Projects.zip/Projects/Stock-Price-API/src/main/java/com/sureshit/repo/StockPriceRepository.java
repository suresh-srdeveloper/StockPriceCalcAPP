package com.sureshit.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sureshit.dao.StockPriceDao;

@Repository
public interface StockPriceRepository extends JpaRepository<StockPriceDao,Integer> {
	public StockPriceDao findByCompany(String company);
}
