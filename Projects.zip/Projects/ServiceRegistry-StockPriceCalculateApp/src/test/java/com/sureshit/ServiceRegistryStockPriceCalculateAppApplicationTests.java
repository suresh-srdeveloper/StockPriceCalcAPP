package com.sureshit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistryStockPriceCalculateAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
