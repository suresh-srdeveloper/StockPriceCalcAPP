package com.sureshit.dto;

public class StockPriceDto {
	
	 
	 
	private String company;
	private Float price;
	 
	 
	 
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	 
	@Override
	public String toString() {
		return "StockPriceDto [company=" + company + ", price=" + price + "]";
	}
	public StockPriceDto(String company, Float price) {
		super();
		this.company = company;
		this.price = price;
	}
	public StockPriceDto() {
		super();
	}

}
