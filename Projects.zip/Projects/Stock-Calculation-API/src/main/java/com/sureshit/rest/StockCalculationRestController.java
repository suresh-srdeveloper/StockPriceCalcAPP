package com.sureshit.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sureshit.client.StockPriceServiceClient;
import com.sureshit.dto.StockPriceDto;

@RestController
public class StockCalculationRestController {

	@Autowired
	private StockPriceServiceClient stockPriceServiceClient;

	@GetMapping("/clc/{cname}/{qty}")
	public String stockCalc(@PathVariable("cname") String cname, @PathVariable("qty") String qty) {

		Float stockPrice = stockPriceServiceClient.invokeStockPriceService(cname);
		Float result = (stockPrice) * (Integer.valueOf(qty));
		return cname + " stock value is : " + result;

	}

}
