package com.sureshit.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("STOCK-PRICE-API")
public interface StockPriceServiceClient {

	@GetMapping("price/{cname}")
	public Float invokeStockPriceService(@PathVariable String cname);
	
}
